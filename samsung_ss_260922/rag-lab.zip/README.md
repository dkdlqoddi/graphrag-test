# rag-lab

PDF 문서를 넣고 물어보는 naive RAG 앱입니다. PDF 에서 글자를 뽑아 조각(청크)으로
자르고, 벡터로 바꿔 저장한 뒤, 질문과 가까운 조각을 꺼내 그 조각만 근거로 답을
만듭니다. 각 단계가 화면에 그대로 보이도록 만들었습니다.

## 실행

```
copy .env.example .env      ← OPENAI_API_KEY 를 넣는다
pip install -r requirements.txt
run.bat                     ← 또는 python app.py
```

브라우저가 `http://127.0.0.1:8765/` 를 엽니다. 시작할 때 `chromadb` · `pypdf` · 키 세 가지를
확인하고, 빠진 것이 있으면 무엇을 설치할지 알려 준 뒤 멈춥니다.

## 화면

네 구획이 왼쪽에서 오른쪽으로 이어지고, 각 구획은 앞 구획의 산출물을 받습니다.

1. **문서** — PDF 를 올리면 페이지별로 뽑아낸 글자 수가 막대로 보입니다. 막대를 누르면
   그 페이지의 원문을 펼쳐 볼 수 있습니다.
2. **청킹** — 자르는 기준 세 가지(고정 길이 · 구조 경계 · 문단)와 조각 크기를 고르면 조각이 카드로 나옵니다.
3. **임베딩·적재** — 조각을 `text-embedding-3-small`(1536차원) 으로 벡터화해 ChromaDB 에 넣습니다.
   검색 결과에 출처를 표시할 수 있도록 조각마다 문서명 · 청크 번호 · 페이지 · 전략을 함께 저장합니다.
4. **검색** — 질문을 같은 모델로 임베딩해 가까운 순으로 K 개를 꺼냅니다. [답변 생성] 을 켜면
   꺼낸 조각만 근거로 `gpt-5.6-luna` 가 답을 씁니다.

## 폴더

```
app.py              시작점. 의존성·키 확인 뒤 서버를 띄운다
run.bat             더블클릭 실행 (UTF-8 콘솔, py/python 자동 탐색)
requirements.txt    chromadb, pypdf
lab/config.py       모델·포트·청킹 기본값
lab/parsing.py      PDF → 글자 (pypdf)
lab/chunking.py     fixed / structure / paragraph
lab/llm.py          임베딩·생성 HTTP 호출 (SDK 없음). 원문이 밖으로 나가는 유일한 지점
lab/store.py        ChromaDB 적재·검색
lab/answer.py       꺼낸 조각으로 답 생성
lab/web.py          로컬 HTTP 서버와 /api/*
static/             index.html · app.js · style.css
data/               올린 PDF 가 놓이는 곳
chroma_db/          적재 결과 (실행 중 생김)
```

## API

`GET /api/status` · `/api/document` · `/api/chunks`
`POST /api/upload` · `/api/chunk` · `/api/embed` · `/api/search` · `/api/vector` · `/api/reset`

파싱·청킹 결과는 메모리에만 있고 서버를 끄면 사라집니다. 적재된 것만 `chroma_db/` 에 남습니다.
